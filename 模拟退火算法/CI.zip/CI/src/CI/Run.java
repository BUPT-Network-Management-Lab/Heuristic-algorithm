package CI;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import Graph.Graph;

public class Run {
	public static void main(String[] args) {
		Graph physic=new Graph("P.txt",true);//55-103
		Graph virtual=new Graph("V.txt",false);//14-21
		double T = 100000,coef = 0.99;//初始温度和降温系数
		int iter=0,iter_in = 0;//外层迭代和内层迭代次数，初始值为0
		int N_iter = 1000,N_iter_in = 100;//迭代次数最大值
		int count = 0;//计数连续多少次未接受新解，以供调参的时候参考
		Map<Integer,Integer> map = new HashMap<Integer,Integer>();//存储已经映射好的虚拟节点和物理节点对，以供下一个虚拟节点映射之前进行查找
		//存储当前解的节点映射结果，下标对应虚拟节点序号，数组值对应物理节点序号
		int [] NodesEmbed = new int[virtual.nodes.length];
		//先随机生成新解，包括：节点映射和链路映射
		for(int i =0;i<virtual.nodes.length;i++)
		{
			Random r = new Random();
			int rand = r.nextInt(physic.nodes.length);
			while(map.containsValue(rand)||
				  physic.nodes[rand].getCapacity()<virtual.nodes[i].getCapacity())
			{
				rand = r.nextInt(physic.nodes.length);
			}
			NodesEmbed[i] = rand;
			map.put(i, rand);
		}
	    //链路映射，link_map存储当前解的链路映射结果，链路映射采用满足带宽的最短路径算法
		Map<Integer,int[]> link_map = LinkEmbedding(physic,virtual,NodesEmbed);
		physic.refreshMatrix();//完成一次全部的链路映射后，将物理网络还原
		int[] bestNodes = NodesEmbed;//给最优解赋初值，将初始解赋值给最优解
		Map<Integer,int[]> bestLinks = link_map;
		int bestCost = 0;//记录最优解的带宽开销
		while(iter<N_iter)
		{
			
			while(iter_in<N_iter_in)
			{
			//生成新解：将当前解赋值给新解，然后随机选取一个虚拟节点进行重映射，再对链路进行重映射
			int[] NeighborNodes = new int[virtual.nodes.length];//存储新解的节点映射结果
			for(int i =0;i<virtual.nodes.length;i++)
			{
				NeighborNodes[i] = NodesEmbed[i];
			}
			Random r = new Random();
			int Virtual = r.nextInt(virtual.nodes.length);
			int Physical = r.nextInt(physic.nodes.length);//对选出的虚拟节点选择重映射的物理节点，要求不能是当前解中被映射过的物理节点
	while(map.containsValue(Physical)||physic.nodes[Physical].getCapacity()<virtual.nodes[Virtual].getCapacity())
			{
				Physical = r.nextInt(physic.nodes.length);
				//System.out.println(Virtual+" "+Physical);
			}
			NeighborNodes[Virtual] = Physical;
			//neighborlinks存储新解的链路映射结果
			Map<Integer,int[]> NeighborLinks = LinkEmbedding(physic,virtual,NeighborNodes);
			physic.refreshMatrix();
			//计算新解和当前解的带宽开销
			int currentCost = 0;
		    int neighborCost = 0;
		    currentCost = BandwidthCost(link_map,virtual);
		    neighborCost = BandwidthCost(NeighborLinks,virtual);
			//判断新解是否被接受
			double de = neighborCost-currentCost;
			System.out.println(neighborCost+" "+de+" "+currentCost);
			if(de <0||Math.exp(-de/T)>Math.random())//新解被接受，更新当前解为新解的映射结果
			{
				for(int i =0;i<virtual.nodes.length;i++)
				{
					NodesEmbed[i] = NeighborNodes[i];
				}
				for(int i = 0;i<virtual.links.length;i++)
				{
					link_map.put(i,NeighborLinks.get(i));	
				}
				map.put(Virtual, Physical);//更新map中节点映射结果，以便之后节点重映射时查找未被映射的物理节点
				count = 0;
		    }
			else //新解未被接受，当前解连续未被更新次数➕1
			{
				count++;
			}
			
			//计算最优解的带宽开销，和当前解进行对比，若当前解开销更小，则更新最优解
			bestCost = BandwidthCost(bestLinks,virtual);
			if(bestCost>currentCost)
			{
				bestNodes = NodesEmbed;
				bestLinks = link_map;
				bestCost = currentCost;
			}
			iter_in++;
		}
			iter++;
			iter_in = 0;
			T *= coef;
		}
		/***********************结果输出************************/
		//System.out.println(iter+" "+iter_in);
		System.out.println("虚拟节点映射结果如下：");
		for(int i = 0;i<virtual.nodes.length;i++)
		{
			System.out.print(i+"->"+bestNodes[i]+";");
		}
		System.out.println();
		System.out.println("虚拟链路映射结果如下：");
		for (Entry<Integer, int[]> entry : bestLinks.entrySet()) {
			int link = entry.getKey();
			int [] path = entry.getValue();
			System.out.print(virtual.links[link].getLeftID()+"->"+virtual.links[link].getRightID()+": ");
			for(int i = 0;i<path.length;i++)
			{
				System.out.print(path[i]+",");
			}
			System.out.println();
		}
		System.out.println("映射带宽开销："+bestCost);
		//System.out.println(count);
		
	}
	//带宽开销计算函数
	public static int BandwidthCost(Map<Integer,int[]> m, Graph G)
	{
		int res =0;
		for (Entry<Integer, int[]> entry : m.entrySet()) {
			int link = entry.getKey();
			int [] path = entry.getValue();
			res+=G.links[link].getBandWidth()*path.length;
		}
		return res;
	}
	//链路映射函数
	public static Map<Integer,int[]> LinkEmbedding(Graph Physic, Graph Virtual,int [] neighborNodes)
	{
		Map<Integer,int[]> res = new HashMap<Integer,int[]>();
		for(int i = 0;i<Virtual.links.length;i++)
		{
			int left = neighborNodes[Virtual.links[i].getLeftID()];
			int right = neighborNodes[Virtual.links[i].getRightID()];
			int [] path = Physic.dijkstra(left, right, Virtual.links[i].getBandWidth());
			res.put(i,path);
		}
		return res;
	}
	
}

