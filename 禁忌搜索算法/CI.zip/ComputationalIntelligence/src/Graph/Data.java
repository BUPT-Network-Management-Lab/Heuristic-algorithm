package Graph;

public class Data {
	public static int FLOW_TABLE_NUM=1000;
	public static int CORE_NUM=16;
	public static int CAPACITY=10000;
	public static int MEMORY=16000;
	public static int BAND_WIDTH=1000;
	public static int LATENCY=5;
	public static String[] TOPO_TYPE = { "FatTree", "BCube", "DCell", "VL2", "CommonTree" };
}
