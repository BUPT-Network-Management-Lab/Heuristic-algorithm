package CI;

import Graph.Graph;
import Graph.Link;
import jdk.internal.org.objectweb.asm.tree.analysis.Value;
import sun.tools.jar.resources.jar;

import java.util.ArrayList;
import java.util.Random;

import org.omg.CORBA.PUBLIC_MEMBER;

import com.sun.java_cup.internal.runtime.virtual_parse_stack;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

public class Run {
	public static void main(String[] args) {
		Graph physic=new Graph("P.txt",true);//55-103
		Graph virtual=new Graph("V.txt",false);//14-21
		//�����ڵ�0������ȡֵ0-54
		physic.nodes[0].getCapacity();
		//����ڵ�0������ȡֵ0-13
		virtual.nodes[0].getCapacity();
		
		//��·ӳ�䣬���·������·��ΪNULL��������ڽӾ���
		int[] path=physic.dijkstra(1, 30, 2000);
		//�ڽӾ���ԭ
		physic.refreshMatrix();
		
		//������·�ڵ�
		virtual.links[0].getLeftID();
		virtual.links[0].getRightID();
		//������·����
		virtual.links[0].getBandWidth();
		
		RandomSearch();
		
		TabuSearch();
	/*	
		Random random = new java.util.Random();
		for(int i=0;i<100;i++)
		{
			System.out.println(random.nextInt(55));
		}
		*/
	}
	public static int[] rs_best = null;
	public static int rs_best_cost;
	
	public static int value(Graph physic,Graph virtual,int[] vnodes) {
		int cost = 0;
		int[] linknodes;
		for(Link pl : virtual.links)
		{
			int left = pl.getLeftID(),right = pl.getRightID();
			linknodes = physic.dijkstra(vnodes[left], vnodes[right], pl.getBandWidth());
			if(linknodes != null)
			{
				cost += pl.getBandWidth() * (linknodes.length - 1);
			}
			else
			{
				cost = Integer.MAX_VALUE;
				break;
			}
		}
		physic.refreshMatrix();
		return cost;
	}
	public static void RandomSearch() {
		Graph physic=new Graph("P.txt",true);//55-103
		Graph virtual=new Graph("V.txt",false);//14-21
		
		Random random = new java.util.Random();
		
		int [] the_bset_scheme = null;
		int the_best_count = 0;
		
		int counter = 1000;

		while(counter-- >0) {
		int [] vnodes = new int[14];
		
		int i=0;
		int j;
		while(i<14)
		{
			int pn = random.nextInt(55);
			if(physic.nodes[pn].getCapacity() < virtual.nodes[i].getCapacity()) //Capicity of physics < Capacity of virtual
			{
				continue;
			}
			for(j=0;j<i;j++)
			{
				if(vnodes[j] == pn)
				{
					break;
				}
			}
			if(j == i)
			{
				vnodes[i] = pn;
				//System.out.println(pn);
				i++;
			}
		}
		//now, vnodes has stored a mapping scheme
		int cost = 0;
		cost = value(physic, virtual, vnodes);
		if(the_bset_scheme == null && cost != Integer.MAX_VALUE)
		{
			the_bset_scheme = vnodes;
			the_best_count = cost;
		}
		else if(the_best_count > cost)
			{
				the_best_count = cost;
				the_bset_scheme = vnodes;
			}
	}
		System.out.println(the_best_count);
		rs_best = the_bset_scheme;
		rs_best_cost = the_best_count;
	}
	////////////////////////////
	public static void copyNodes(int[] a,int b[]) {
		for(int i=0;i<14;i++)
		{
			b[i] = a[i];
		}
	}
	//judge if array a is equal to array b
	public static boolean theSame(int[] a,int[] b) {
		for(int i=0;i<14;i++)
		{
			if(a[i] != b[i])
			{
				return false;
			}
		}
		return true;
	}
	public static  boolean isInTabuTable(int[][] TabuTable,int[] vnodes,int tabuTableLen) {
		for(int i=0;i<tabuTableLen;i++)
		{
			if(theSame(TabuTable[i], vnodes))
			{
				return true;
			}
		}
		return false;
	}
	//get one neighbor
	public int[] getOneNeighbor(int[] vnodes) {
		int[] neighbor = new int[14];
		int ran1,ran2,temp;
		
		Random random = new java.util.Random();
		
		copyNodes(vnodes, neighbor);
		
		ran1 = random.nextInt(14);
		do {
			ran2 = random.nextInt(14);
		} while (ran1 == ran2);
		temp = neighbor[ran1];
		neighbor[ran1] = neighbor[ran2];
		neighbor[ran2] = temp;
		
		return neighbor;
	}
	//get several neighbors
	public static int[][] getNeighbors(int[] vnodes,int neighborNum,int[][] TabuTable,int tabuTableLen,Graph physic,Graph virtual) {
		int[] tempNodes;
		int temp;
		int ran1,ran2;
		boolean iscontinue;
		int[][] neighbors = new int[neighborNum][];
		int[][] tempExchangeNodeList = new int[neighborNum][2];
		Random random = new java.util.Random();
		for(int i=0;i<neighborNum;i++)
		{
			
			tempNodes = new int[14];
			copyNodes(vnodes, tempNodes);
			do {
			iscontinue = false;
			ran1 = random.nextInt(14);
			do {
				ran2 = random.nextInt(14);
			} while (ran2 == ran1);
			for(int m=0;m<i;m++)
			{
				if(tempExchangeNodeList[m][0]==ran1 && tempExchangeNodeList[m][1]==ran2 || tempExchangeNodeList[m][0]==ran2 && tempExchangeNodeList[m][1]==ran1)
				{
					iscontinue = true;
					break;
				}
			}
			if(iscontinue==false)
			{
				temp = tempNodes[ran1];
				tempNodes[ran1] = tempNodes[ran2];
				tempNodes[ran2] = temp;
				for(int l=0;l<14;l++)
				{
					if(virtual.nodes[l].getCapacity() > physic.nodes[tempNodes[l]].getCapacity())
					{
						iscontinue = true;
						break;
					}
				}
				if(theSame(tempNodes, vnodes))
				{
					iscontinue = true;
				}
				if(iscontinue==false && !isInTabuTable(TabuTable, tempNodes, tabuTableLen))
				{
					neighbors[i] = tempNodes;
					tempExchangeNodeList[i][0] = ran1;
					tempExchangeNodeList[i][1] = ran2;
				}
				else
				{
					iscontinue = true;
				}
			}
			}while(iscontinue);
		}
		return neighbors;
	}
	
	public static void flushTabuTable(int[][] TabuTable,int[] tabuTableEvaluate,int len,int[] vnodes,int[] currentnodes,Graph physic,Graph virtual) {
		int tempValue = value(physic, virtual, vnodes);
		int tempMax = tabuTableEvaluate[0];
		int maxValueIndex = 0;
		for(int i=1;i<len;i++)
		{
			if(tabuTableEvaluate[i] > tempMax)
			{
				tempMax = tabuTableEvaluate[i];
				maxValueIndex = i;
			}
		}
		if(tempValue<tempMax)
		{
			if(tempMax<Integer.MAX_VALUE)
			{ 
				copyNodes(TabuTable[maxValueIndex], currentnodes);
			}
			copyNodes(vnodes, TabuTable[maxValueIndex]);
			tabuTableEvaluate[maxValueIndex] = tempValue;
		}
	}
	public static void TabuSearch() {
		Graph physic=new Graph("P.txt",true);//55-103
		Graph virtual=new Graph("V.txt",false);//14-21
		
		
		int[] currentbestscheme=rs_best;  //the result of random search
		int currentbestcost=rs_best_cost;//the result of random search
		int[] currentscheme = rs_best; //the result of random search 
		
		int bestcost=Integer.MAX_VALUE;
		int[] bestscheme = new int[14];
		
		int MAX_GEN = 10;
		int neighbornum = 10;
		int len = 10;//length of TabuTable
		int [][] TabuTable =new int[len][14];
		int[] tabuTableEvaluate = new int[len];
		int[][] neighbors;
		int[] neighbor;
		int neighborValue;
		
		int currentIterateNum = 0;
		
		
		for(int i=0;i<len;i++)
		{
			tabuTableEvaluate[i] = Integer.MAX_VALUE;
			for(int j=0;j<14;j++)
			{
				TabuTable[i][j]=0;
			}
		}
		
		while(currentIterateNum < MAX_GEN)
		{
			neighbors = getNeighbors(currentscheme, neighbornum,TabuTable,len,physic,virtual);
			for(int i=0;i<neighbornum;i++)
			{
				neighbor = neighbors[i];
				neighborValue = value(physic, virtual, neighbor);
				if(neighborValue<currentbestcost)
				{
					copyNodes(neighbor, currentbestscheme);
					currentbestcost = neighborValue;
				}
			}
			if(currentbestcost<bestcost)
			{
				copyNodes(currentbestscheme, bestscheme);
				bestcost = currentbestcost;
			}
			copyNodes(currentbestscheme, currentscheme);
			flushTabuTable(TabuTable, tabuTableEvaluate, len, currentbestscheme,currentscheme, physic, virtual);
			currentIterateNum++;
		}
		System.out.println(bestcost);
	}
}



































































